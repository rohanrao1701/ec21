#Network Hardening Recipe

#Ensure that sysctl exists
file '/etc/sysctl.conf' do
  mode 0644
  owner 'root'
  group 'root'
  action :create
end

#Restrict parameters
replace_or_add 'net.ipv4.ip_forward=0' do
    path '/etc/sysctl.conf'
    pattern 'net.ipv4.ip_forward'
    line 'net.ipv4.ip_forwards=0'
end

replace_or_add 'net.ipv4.conf.all.forwarding' do
    path '/etc/sysctl.conf'
    pattern 'net.ipv4.conf.all.forwarding'
    line 'net.ipv4.conf.all.forwarding=0'
end

replace_or_add 'net.ipv6.conf.all.accept_ra' do
    path '/etc/sysctl.conf'
    pattern 'net.ipv6.conf.all.accept_ra'
    line 'net.ipv6.conf.all.accept_ra=0'
end

replace_or_add 'net.ipv4.conf.default.accept_source_route' do
    path '/etc/sysctl.conf'
    pattern 'net.ipv4.conf.default.accept_source_route'
    line 'net.ipv4.conf.default.accept_source_route=0'
end

replace_or_add 'net.ipv6.conf.default.accept_ra' do
    path '/etc/sysctl.conf'
    pattern 'net.ipv6.conf.default.accept_ra'
    line 'net.ipv6.conf.default.accept_ra=0'
end

replace_or_add 'net.ipv4.icmp_echo_ignore_broadcasts' do
    path '/etc/sysctl.conf'
    pattern 'net.ipv4.icmp_echo_ignore_broadcasts'
    line 'net.ipv4.icmp_echo_ignore_broadcasts=1'
end

replace_or_add 'net.ipv4.icmp_ignore_bogus_error_message' do
    path '/etc/sysctl.conf'
    pattern 'net.ipv4.icmp_ignore_bogus_error_message'
    line 'net.ipv4.icmp_ignore_bogus_error_message=1'
end

replace_or_add 'kernel.randomize_va_space' do
    path '/etc/sysctl.conf'
    pattern 'kernel.randomize_va_space'
    line 'kernel.randomize_va_space=1'
end

replace_or_add 'net.ipv4.conf.default.log_martians=1' do
    path '/etc/sysctl.conf'
    pattern 'net.ipv4.conf.default.log_martians'
    line 'net.ipv4.conf.default.log_martians=1'
end
