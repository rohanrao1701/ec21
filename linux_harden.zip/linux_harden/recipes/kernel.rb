#Recipe to disable filesystems and kernel mods
modules = %w( dccp rds sctp tipc cramfs fat freevxfs hfs hfsplus jffs2 squashfs udf vfat )

modules.each do |mod|
  execute "rmmod #{mod}" do
    only_if "lsmod | grep #{mod}"
  end

  file "blacklist #{mod}" do
    path "/etc/modprobe.d/#{mod}.conf"
    content "install #{mod} /bin/true"
  end
end
