
package 'Install grub2' do
  package_name 'grub2'
  action :install
end

file '/boot/grub2/grub.cfg' do
  mode '0600'
  owner 'root'
  group 'root'
  action :create
end
