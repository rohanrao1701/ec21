#
# Cookbook:: build_cookbook
# Recipe:: syntax
#
# Copyright:: 2018, The Authors, All Rights Reserved.
include_recipe 'delivery-truck::syntax'
