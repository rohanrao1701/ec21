name 'linux_harden'
maintainer 'Rohan Ravinder'
maintainer_email 'rohan.ravinder@perficient.com'
license 'All Rights Reserved'
description 'Linux Hardening Cookbook'
long_description 'Primary Linux Hardening cookbook'
version '1.0.0'
chef_version '>= 12.14' if respond_to?(:chef_version)

supports 'centos'
depends 'line', '~> 1.0.0'
