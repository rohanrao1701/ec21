# linux_harden

TODO: Enter the cookbook description here.

