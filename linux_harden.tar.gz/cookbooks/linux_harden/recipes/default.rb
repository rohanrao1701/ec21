#Linux Hardening cookbook

case node['platform_family']
when 'rhel'
  if node['platform_version'].to_f >= 7.0

include_recipe 'linux_harden::kernel'
include_recipe 'linux_harden::grub'
include_recipe 'linux_harden::network'
include_recipe 'linux_harden::lockdown'
include_recipe 'linux_harden::directory'
include_recipe 'linux_harden::systemex'
include_recipe 'linux_harden::packages'

  end
end
