#Locking down system directories

directory '/var/log/' do
  mode '0711'
  recursive true
  owner 'root'
  group 'root'
end

directory '/usr/etc' do
  mode '0711'
  recursive true
  owner 'root'
  group 'root'
end

directory '/usr/local/etc' do
  mode '0711'
  recursive true
  owner 'root'
  group 'root'
end

directory '/usr/local/bin' do
  mode '0711'
  recursive true
  owner 'root'
  group 'root'
end

directory '/root' do
  mode '0700'
  recursive true
  owner 'root'
  group 'root'
end
