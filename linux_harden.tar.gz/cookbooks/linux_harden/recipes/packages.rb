package %w(apmd as avahi-daemon bluetooth bin86 cups dhcpd dhcpv6-client ftp finger gcc* gpm gtk2 smb ModemManager-glib make hotplug krb5-appl-clients
  nano NetworkManager)  do
  action :remove
end
