
file '/etc/passwd' do
  mode '0444'
  owner 'root'
  group 'root'
end

file '/etc/group' do
  mode '0400'
  owner 'root'
  group 'root'
end

file '/etc/shadow' do
  mode '0400'
  owner 'root'
  group 'root'
end

file '/etc/ssh/sshd_config' do
  mode '0400'
  owner 'root'
  group 'root'
end

file '/etc/sudoers' do
  mode '0644'
  owner 'root'
  group 'root'
end

file '/etc/sysctl.conf' do
  mode '0700'
  owner 'root'
  group 'root'
end

file '/etc/inittab' do
  mode '0700'
  owner 'root'
  group 'root'
end

file '/etc/fstab' do
  mode '0644'
  owner 'root'
  group 'root'
end

file '/etc/crontab' do
  mode '0600'
  owner 'root'
  group 'root'
end

file '/etc/cron_monthly' do
  mode '0600'
  owner 'root'
  group 'root'
end

file '/etc/cron_weekly' do
  mode '0600'
  owner 'root'
  group 'root'
end

file '/etc/cron_daily' do
  mode '0600'
  owner 'root'
  group 'root'
end

file '/etc/motd' do
  mode '0600'
  owner 'root'
  group 'root'
end

file '/etc/group' do
  mode '0600'
  owner 'root'
  group 'root'
end

file '/etc/issue' do
  mode '0600'
  owner 'root'
  group 'root'
end

file '/etc/issue.net' do
  mode '0600'
  owner 'root'
  group 'root'
end
