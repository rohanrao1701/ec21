#Locking down system executables

file '/bin/dmesg' do
  mode 0550
  owner 'root'
  group 'root'
end

file '/bin/mount' do
  mode 0550
  owner 'root'
  group 'root'
end

file '/bin/rpm' do
  mode 0550
  owner 'root'
  group 'root'
end

file '/usr/bin/write' do
  mode 0550
  owner 'root'
  group 'root'
end

file '/usr/bin/talk' do
  mode 0550
  owner 'root'
  group 'root'
end

file '/usr/bin/ipcs' do
  mode 0550
  owner 'root'
  group 'root'
end

file '/usr/bin/free' do
  mode 0550
  owner 'root'
  group 'root'
end

file '/usr/bin/locate' do
  mode 0550
  owner 'root'
  group 'root'
end

file '/sbin/arp' do
  mode 0550
  owner 'root'
  group 'root'
end

file '/sbin/ipconfig' do
  mode 0550
  owner 'root'
  group 'root'
end

file '/bin/tracepath' do
  mode 0550
  owner 'root'
  group 'root'
end

file '/bin/tracepath6' do
  mode 0550
  owner 'root'
  group 'root'
end

file '/bin/traceroute' do
  mode 0550
  owner 'root'
  group 'root'
end

file '/usr/sbin/repquota' do
  mode 0550
  owner 'root'
  group 'root'
end

file '/usr/sbin/tcpdump' do
  mode 0550
  owner 'root'
  group 'root'
end

file '/usr/bin/wget' do
  mode 0550
  owner 'root'
  group 'root'
end

file '/usr/bin/perlcc' do
  mode 0550
  owner 'root'
  group 'root'
end

file '/usr/bin/who' do
  mode 0550
  owner 'root'
  group 'root'
end
